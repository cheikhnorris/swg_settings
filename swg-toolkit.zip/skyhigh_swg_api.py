#!/usr/bin/env python3
"""
Skyhigh Secure Web Gateway (On-Prem) - REST API Client
=======================================================
Pulls appliance configuration and settings via the SWG REST API.

API base: https://<appliance>:4712/Konfigurator/REST/
Authentication: HTTP Basic Auth (admin credentials)
Content-Type: application/json or application/xml

Reference:
  https://success.skyhighsecurity.com/Skyhigh_Secure_Web_Gateway_(On-Prem)/
    Secure_Web_Gateway_Product_Guide/REST_Interface/Working_with_configurations_and_settings

Usage:
  python skyhigh_swg_api.py --host 192.168.1.10 --user admin --password secret
  python skyhigh_swg_api.py --host 192.168.1.10 --user admin --password secret --output results.json
  python skyhigh_swg_api.py --host 192.168.1.10 --user admin --password secret --endpoint appliances
"""

import argparse
import json
import logging
import sys
import urllib.parse
from datetime import datetime
from typing import Any, Dict, List, Optional

import requests
import urllib3

# Suppress InsecureRequestWarning for self-signed certs (common on appliances)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# SWG REST client
# ---------------------------------------------------------------------------
class SWGClient:
    """
    Thin wrapper around the Skyhigh SWG REST API.

    The SWG REST interface is exposed on port 4712 (HTTPS) by default.
    All requests use HTTP Basic Auth.  Responses can be JSON or XML;
    this client requests JSON (Accept: application/json).

    Key API paths (relative to /Konfigurator/REST/):
        appliances                  – list of managed appliances / nodes
        appliances/{id}             – single appliance details
        settings                    – top-level configuration settings
        settings/{section}          – a specific settings section
        configurations              – named configuration objects
        configurations/{name}       – a single named configuration
        policies                    – policy sets
        lists                       – list objects (URL lists, IP lists, …)
        licenses                    – license information
        version                     – product version info
    """

    DEFAULT_PORT = 4712
    BASE_PATH = "/Konfigurator/REST"

    def __init__(
        self,
        host: str,
        username: str,
        password: str,
        port: int = DEFAULT_PORT,
        verify_ssl: bool = False,
        timeout: int = 30,
    ):
        self.host = host
        self.username = username
        self.password = password
        self.port = port
        self.verify_ssl = verify_ssl
        self.timeout = timeout

        self.base_url = f"https://{host}:{port}{self.BASE_PATH}"
        self.session = requests.Session()
        self.session.auth = (username, password)
        self.session.headers.update(
            {
                "Accept": "application/json",
                "Content-Type": "application/json",
            }
        )
        self.session.verify = verify_ssl

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------
    def _url(self, path: str) -> str:
        """Build a full URL from a relative API path."""
        # Normalise: remove leading slash so we don't double-up
        path = path.lstrip("/")
        return f"{self.base_url}/{path}"

    def _get(self, path: str, params: Optional[Dict] = None) -> Any:
        """
        Execute a GET request and return parsed JSON.
        Raises requests.HTTPError on 4xx/5xx responses.
        """
        url = self._url(path)
        log.debug("GET %s  params=%s", url, params)
        resp = self.session.get(url, params=params, timeout=self.timeout)
        resp.raise_for_status()
        # Some endpoints return empty body on success
        if not resp.content:
            return {}
        try:
            return resp.json()
        except ValueError:
            # Fall back to raw text if response isn't JSON
            return {"raw": resp.text}

    # ------------------------------------------------------------------
    # Authentication test
    # ------------------------------------------------------------------
    def test_connection(self) -> bool:
        """Verify credentials and reachability by fetching the version endpoint."""
        try:
            data = self._get("version")
            log.info("Connected to SWG at %s  –  %s", self.host, data)
            return True
        except requests.ConnectionError as exc:
            log.error("Cannot reach %s:%s – %s", self.host, self.port, exc)
            return False
        except requests.HTTPError as exc:
            log.error("Authentication / HTTP error – %s", exc)
            return False

    # ------------------------------------------------------------------
    # Version / product info
    # ------------------------------------------------------------------
    def get_version(self) -> Dict:
        """Return product version information."""
        return self._get("version")

    # ------------------------------------------------------------------
    # Appliances / nodes
    # ------------------------------------------------------------------
    def get_appliances(self) -> List[Dict]:
        """
        Return the list of all managed appliances (nodes) in the cluster.

        Endpoint: GET /Konfigurator/REST/appliances
        Response contains appliance IDs, hostnames, IP addresses,
        roles (standalone / central management / scanner), status, etc.
        """
        data = self._get("appliances")
        # The API wraps the list; normalise to always return a list
        if isinstance(data, list):
            return data
        # Handle wrapper objects like {"appliances": [...]}
        for key in ("appliances", "nodes", "results", "items"):
            if key in data:
                return data[key]
        return [data] if data else []

    def get_appliance(self, appliance_id: str) -> Dict:
        """Return details for a single appliance by ID."""
        return self._get(f"appliances/{urllib.parse.quote(appliance_id, safe='')}")

    # ------------------------------------------------------------------
    # Settings
    # ------------------------------------------------------------------
    def get_settings(self) -> Dict:
        """
        Return the top-level settings structure.

        Endpoint: GET /Konfigurator/REST/settings
        """
        return self._get("settings")

    def get_settings_section(self, section: str) -> Dict:
        """
        Return a specific settings section, e.g. 'proxies', 'network', 'logging'.

        Endpoint: GET /Konfigurator/REST/settings/{section}
        """
        return self._get(f"settings/{urllib.parse.quote(section, safe='')}")

    # ------------------------------------------------------------------
    # Configurations
    # ------------------------------------------------------------------
    def get_configurations(self) -> List[Dict]:
        """
        Return all named configuration objects.

        Endpoint: GET /Konfigurator/REST/configurations
        """
        data = self._get("configurations")
        if isinstance(data, list):
            return data
        for key in ("configurations", "results", "items"):
            if key in data:
                return data[key]
        return [data] if data else []

    def get_configuration(self, name: str) -> Dict:
        """Return a single named configuration."""
        return self._get(f"configurations/{urllib.parse.quote(name, safe='')}")

    # ------------------------------------------------------------------
    # Policies
    # ------------------------------------------------------------------
    def get_policies(self) -> List[Dict]:
        """
        Return all policy sets.

        Endpoint: GET /Konfigurator/REST/policies
        """
        data = self._get("policies")
        if isinstance(data, list):
            return data
        for key in ("policies", "results", "items"):
            if key in data:
                return data[key]
        return [data] if data else []

    def get_policy(self, policy_id: str) -> Dict:
        """Return a single policy by ID or name."""
        return self._get(f"policies/{urllib.parse.quote(policy_id, safe='')}")

    # ------------------------------------------------------------------
    # Lists (URL lists, IP lists, …)
    # ------------------------------------------------------------------
    def get_lists(self) -> List[Dict]:
        """
        Return all configured lists (URL categories, IP allow/block lists, …).

        Endpoint: GET /Konfigurator/REST/lists
        """
        data = self._get("lists")
        if isinstance(data, list):
            return data
        for key in ("lists", "results", "items"):
            if key in data:
                return data[key]
        return [data] if data else []

    def get_list(self, list_id: str) -> Dict:
        """Return a single list object by ID or name."""
        return self._get(f"lists/{urllib.parse.quote(list_id, safe='')}")

    # ------------------------------------------------------------------
    # Licenses
    # ------------------------------------------------------------------
    def get_licenses(self) -> Dict:
        """
        Return license information.

        Endpoint: GET /Konfigurator/REST/licenses
        """
        return self._get("licenses")

    # ------------------------------------------------------------------
    # Cluster / Central Management
    # ------------------------------------------------------------------
    def get_cluster_nodes(self) -> List[Dict]:
        """
        Return all nodes registered in a Central Management (CM) cluster.

        Endpoint: GET /Konfigurator/REST/cluster/nodes
        This is an alias / alternative path sometimes used in CM-aware setups.
        """
        try:
            data = self._get("cluster/nodes")
        except requests.HTTPError as exc:
            if exc.response is not None and exc.response.status_code == 404:
                log.debug("cluster/nodes not available on this appliance (standalone?)")
                return []
            raise
        if isinstance(data, list):
            return data
        for key in ("nodes", "results", "items"):
            if key in data:
                return data[key]
        return [data] if data else []

    # ------------------------------------------------------------------
    # Convenience: pull everything at once
    # ------------------------------------------------------------------
    def collect_all(self) -> Dict:
        """
        Fetch all supported endpoints and return a single consolidated dict.
        Errors on individual endpoints are caught and recorded rather than
        aborting the whole collection.
        """
        result: Dict[str, Any] = {
            "collected_at": datetime.utcnow().isoformat() + "Z",
            "host": self.host,
        }

        endpoints = {
            "version": self.get_version,
            "appliances": self.get_appliances,
            "cluster_nodes": self.get_cluster_nodes,
            "settings": self.get_settings,
            "configurations": self.get_configurations,
            "policies": self.get_policies,
            "lists": self.get_lists,
            "licenses": self.get_licenses,
        }

        for key, fn in endpoints.items():
            log.info("Fetching %s …", key)
            try:
                result[key] = fn()
                log.info("  ✓  %s", key)
            except requests.HTTPError as exc:
                status = exc.response.status_code if exc.response is not None else "?"
                log.warning("  ✗  %s  (HTTP %s)", key, status)
                result[key] = {"error": str(exc), "http_status": status}
            except Exception as exc:  # pylint: disable=broad-except
                log.warning("  ✗  %s  (%s)", key, exc)
                result[key] = {"error": str(exc)}

        return result


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Pull Skyhigh SWG On-Prem appliance data via REST API",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    p.add_argument("--host", required=True, help="Appliance hostname or IP")
    p.add_argument("--port", type=int, default=SWGClient.DEFAULT_PORT,
                   help=f"REST API port (default: {SWGClient.DEFAULT_PORT})")
    p.add_argument("--user", required=True, help="Admin username")
    p.add_argument("--password", required=True, help="Admin password")
    p.add_argument(
        "--endpoint",
        default="all",
        choices=[
            "all", "version", "appliances", "cluster_nodes",
            "settings", "configurations", "policies", "lists", "licenses",
        ],
        help="Which endpoint to query (default: all)",
    )
    p.add_argument(
        "--section",
        help="Settings section name (used when --endpoint=settings, e.g. proxies)",
    )
    p.add_argument(
        "--appliance-id",
        help="Appliance ID to query (used when --endpoint=appliances)",
    )
    p.add_argument(
        "--output", "-o",
        help="Write JSON output to this file (default: print to stdout)",
    )
    p.add_argument(
        "--verify-ssl",
        action="store_true",
        help="Verify TLS certificate (disabled by default; appliances use self-signed certs)",
    )
    p.add_argument(
        "--timeout",
        type=int,
        default=30,
        help="HTTP request timeout in seconds (default: 30)",
    )
    p.add_argument(
        "--pretty",
        action="store_true",
        help="Pretty-print JSON output",
    )
    p.add_argument(
        "--debug",
        action="store_true",
        help="Enable debug logging",
    )
    return p


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    if args.debug:
        logging.getLogger().setLevel(logging.DEBUG)

    client = SWGClient(
        host=args.host,
        username=args.user,
        password=args.password,
        port=args.port,
        verify_ssl=args.verify_ssl,
        timeout=args.timeout,
    )

    # Connectivity check
    if not client.test_connection():
        log.error("Failed to connect to %s. Aborting.", args.host)
        return 1

    # Dispatch to the right method
    try:
        endpoint = args.endpoint
        if endpoint == "all":
            data = client.collect_all()

        elif endpoint == "version":
            data = client.get_version()

        elif endpoint == "appliances":
            if args.appliance_id:
                data = client.get_appliance(args.appliance_id)
            else:
                data = client.get_appliances()

        elif endpoint == "cluster_nodes":
            data = client.get_cluster_nodes()

        elif endpoint == "settings":
            if args.section:
                data = client.get_settings_section(args.section)
            else:
                data = client.get_settings()

        elif endpoint == "configurations":
            data = client.get_configurations()

        elif endpoint == "policies":
            data = client.get_policies()

        elif endpoint == "lists":
            data = client.get_lists()

        elif endpoint == "licenses":
            data = client.get_licenses()

        else:
            log.error("Unknown endpoint: %s", endpoint)
            return 1

    except requests.HTTPError as exc:
        log.error("HTTP error: %s", exc)
        return 1
    except requests.ConnectionError as exc:
        log.error("Connection error: %s", exc)
        return 1

    # Output
    indent = 2 if args.pretty else None
    json_out = json.dumps(data, indent=indent, default=str)

    if args.output:
        with open(args.output, "w", encoding="utf-8") as fh:
            fh.write(json_out)
        log.info("Results written to %s", args.output)
    else:
        print(json_out)

    return 0


if __name__ == "__main__":
    sys.exit(main())
