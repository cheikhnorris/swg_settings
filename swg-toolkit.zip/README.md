# Skyhigh Secure Web Gateway (On-Prem) — REST API Toolkit

A Python toolkit for interacting with the **Skyhigh / McAfee Secure Web Gateway (SWG) On-Prem** REST API, focused on pulling and auditing all appliance settings and configuration.

> **Tested against:** SWG versions 10.x, 11.x, 12.x (McAfee Web Gateway lineage)  
> **API base:** `https://<appliance>:4712/Konfigurator/REST`

---

## Contents

| File | Purpose |
|---|---|
| `skyhigh_swg_settings.py` | **Main script** — pulls all 60+ settings sections in parallel, with full session lifecycle, list inventory, and file inventory |
| `skyhigh_swg_api.py` | General-purpose REST client covering all top-level endpoints (appliances, settings, policies, lists, licenses) |
| `examples/` | Usage examples and sample output |
| `docs/SECTIONS.md` | Complete catalogue of all known settings sections with descriptions |
| `docs/ENRICHMENTS.md` | GitHub research findings that enriched this toolkit |

---

## Quick Start

```bash
pip install requests

# Pull all settings — pretty-print to stdout
python skyhigh_swg_settings.py --host 192.168.1.10 --user admin --password s3cr3t --pretty

# Save full report to file
python skyhigh_swg_settings.py --host 192.168.1.10 --user admin --password s3cr3t \
    --output report.json --pretty

# Discover which sections exist on your appliance
python skyhigh_swg_settings.py --host 192.168.1.10 --user admin --password s3cr3t --discover

# Pull only one section
python skyhigh_swg_settings.py --host 192.168.1.10 --user admin --password s3cr3t \
    --section ProxySetting --pretty

# List all known section names (no network call)
python skyhigh_swg_settings.py --list-sections
```

---

## Authentication

The SWG REST API supports two authentication methods, both implemented here:

**1. Cookie-based session (preferred)**  
`POST /login` → receives `JSESSIONID` cookie → used for all subsequent requests → `POST /logout`

**2. HTTP Basic Auth (fallback)**  
Used automatically when cookie login fails or is unavailable.

---

## Settings Sections Covered

60+ named configuration sections across 18 functional areas:

| Area | Sections |
|---|---|
| Proxy / Network | `ProxySetting`, `ProxyIcapSetting`, `FtpProxySetting`, `SocksSetting`, `NetworkSetting`, `DnsSetting`, `RoutingSetting`, `NtpSetting`, `HostsSetting` |
| SSL / TLS | `SslSetting`, `SslClientContextSetting`, `SslServerContextSetting`, `SslCaCertificateSetting`, `SslCertificateSetting` |
| Authentication | `AuthenticationSetting`, `NtlmSetting`, `KerberosSetting`, `LdapSetting`, `RadiusSetting`, `SamlSetting`, `EDirectory`, `ProxyAuthSetting`, `KcdSetting` |
| Logging | `LogSetting`, `ErrorLogSetting`, `AuditLogSetting`, `SyslogSetting`, `MwgLogSetting`, `StatisticsSetting` |
| Anti-Malware | `AntiMalwareSetting`, `AvSetting`, `TieServerSetting`, `AtdSetting`, `GtiSetting`, `CloudLookupSetting` |
| URL Filtering | `UrlFilterSetting`, `CategorySetting` |
| Content / DLP | `ContentInspectionSetting`, `DlpSetting`, `MediaTypeSetting` |
| HTTP | `HttpSetting`, `HttpTimeoutSetting`, `HttpCacheSetting`, `CompressionSetting`, `CacheSetting` |
| Users / Roles | `UserSetting`, `RoleSetting` |
| Notifications | `NotificationSetting`, `AlertSetting`, `SmtpSetting`, `SnmpSetting` |
| Central Mgmt | `CentralManagementSetting`, `ClusterSetting`, `ConfigurationBackupSetting` |
| Updates | `UpdateSetting`, `EngineUpdateSetting` |
| High Availability | `HaSetting` |
| System | `HealthSetting`, `SystemSetting`, `DiagnosticSetting` |
| PAC / Bypass | `PacSetting`, `BypassSetting` |
| Reporting | `ReportingSetting`, `DashboardSetting` |
| ICAP | `IcapSetting`, `IcapClientSetting` |
| Engine | `EngineSetting`, `CoreSetting` |

Run `python skyhigh_swg_settings.py --list-sections` for the full annotated list.

---

## List Types

SWG list IDs follow the format `com.scur.type.<type>.<number>`:

| Type | Description |
|---|---|
| `regex` | URL/pattern lists — most common block/allow list type |
| `ip` | IP address lists (CIDR notation supported) |
| `string` | Arbitrary string lists (hostnames, user-agents, etc.) |
| `number` | Numeric value lists (port numbers, response codes) |
| `category` | Web category lists (numeric category IDs) |
| `mediatype` | MIME/media-type lists |

---

## Output Format

The full report is a single JSON document:

```json
{
  "meta": {
    "collected_at": "2026-03-30T10:00:00Z",
    "host": "192.168.1.10",
    "port": 4712,
    "auth_method": "JSESSIONID"
  },
  "version": { ... },
  "appliances": [ ... ],
  "settings_root": { ... },
  "settings": {
    "ProxySetting": { ... },
    "SslSetting": { ... },
    "LdapSetting": { ... },
    ...
  },
  "lists": { ... },
  "log_files": { ... },
  "section_catalogue": { ... }
}
```

Sections that return HTTP 404 (not present on this firmware) are recorded as `{"_error": "...", "_http_status": 404}` rather than causing the run to abort.

---

## CLI Reference

```
usage: skyhigh_swg_settings.py [-h]
                                [--host HOST] [--port PORT]
                                [--user USER] [--password PASSWORD]
                                [--verify-ssl] [--timeout TIMEOUT] [--workers N]
                                [--section NAME] [--list-sections] [--discover]
                                [--no-lists] [--no-files] [--no-meta]
                                [--output FILE] [--pretty] [--debug]

Connection:
  --host          Appliance hostname or IP
  --port          REST API port (default: 4712)
  --user          Admin username
  --password      Admin password
  --verify-ssl    Verify TLS certificate (off by default)
  --timeout       Per-request timeout in seconds (default: 30)
  --workers       Parallel HTTP workers (default: 8)

Mode:
  --section NAME  Fetch only this one settings section
  --list-sections Print catalogue of all known sections (no network)
  --discover      Probe all sections and report which respond HTTP 200
  --no-lists      Skip list inventory
  --no-files      Skip log/troubleshooting file inventory
  --no-meta       Omit catalogue metadata from output

Output:
  --output FILE   Write JSON to file (default: stdout)
  --pretty        Pretty-print JSON (2-space indent)
  --debug         Enable DEBUG logging
```

---

## Important API Notes

### Commit is mandatory for writes
Any `PUT`, `POST`, or `DELETE` on lists or settings **must** be followed by:
```
POST /Konfigurator/REST/commit
```
Without this, changes are staged but never persisted — they will be lost on reload.

### Always backup before writes
```
POST /Konfigurator/REST/backup
```
The `SWGClient.backup()` method handles this automatically.

### SSL certificates
Appliances ship with self-signed certificates. `--verify-ssl` is off by default. In production, install a proper certificate and enable verification.

---

## Research & Enrichments

This toolkit was enriched by analysing the following public GitHub repositories and documentation:

- [`SkyhighSecurity/ScannerAPI-Python`](https://github.com/SkyhighSecurity/ScannerAPI-Python) — Official ICAP-to-REST bridge
- [`SkyhighSecurity/ScannerAPI`](https://github.com/SkyhighSecurity/ScannerAPI) — Official C# version
- [`SkyhighSecurity/skyhigh-trellix-dod-integrator`](https://github.com/SkyhighSecurity/skyhigh-trellix-dod-integrator) — ATD/TIS integration
- [`firewallops/SwgAssistant`](https://github.com/firewallops/SwgAssistant) — Community Python assistant
- [`mohlcyber/McAfee-Web-Gateway-List-Update`](https://github.com/mohlcyber/McAfee-Web-Gateway-List-Update) — Community list management
- [`Ipv6Python/mcafee-mwgapi`](https://github.com/Ipv6Python/mcafee-mwgapi) — Community pip package
- [`IntelSecurityGroup/webgateway`](https://github.com/IntelSecurityGroup/webgateway) — Go implementation
- Palo Alto Cortex XSOAR [McAfeeWebGateway pack](https://xsoar.pan.dev/docs/reference/integrations/skyhigh-secure-web-gateway-on-prem) — Production SOAR integration
- McAfee/Skyhigh MWG 11.0 Product Guide REST Appendix (PDF)

See [`docs/ENRICHMENTS.md`](docs/ENRICHMENTS.md) for the full breakdown.

---

## Requirements

```
requests>=2.28.0
```

Python 3.8+

---

## License

MIT
