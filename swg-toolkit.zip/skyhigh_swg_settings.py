#!/usr/bin/env python3
"""
Skyhigh / McAfee Secure Web Gateway (On-Prem) – Enriched Settings Collector
=============================================================================
Enriched based on findings from the following public GitHub repositories and
community sources:

  1. SkyhighSecurity/ScannerAPI-Python  (official)
       → ICAP-based AV/DLP scan REST front-end; revealed ICAP endpoint structure
  2. SkyhighSecurity/ScannerAPI          (official C# version, same patterns)
  3. SkyhighSecurity/skyhigh-trellix-dod-integrator  (official)
       → ATD/TIS integration; confirmed AtdSetting & TieServerSetting paths
  4. firewallops/SwgAssistant             (community, Python, MIT)
       → Session / cookie auth pattern (JSESSIONID) confirmed
  5. mohlcyber/McAfee-Web-Gateway-List-Update  (community, Python)
       → Confirmed: POST /login → JSESSIONID cookie
         GET  /list   (all lists)
         GET  /list/{id}
         POST /list/{id}/entry/{pos}/insert   (add entry)
         PUT  /list/{id}/entry/{pos}          (update entry)
         DELETE /list/{id}/entry/{pos}        (remove entry)
         POST /commit   (required after any write)
         POST /backup   (config backup)
         POST /logout
  6. Ipv6Python/mcafee-mwgapi             (community pip package)
       → authenticate / appliances / listdata modules; session reuse pattern
  7. IntelSecurityGroup/webgateway        (Go, community)
       → Same cookie-based session pattern confirmed in a different language
  8. Palo Alto Cortex XSOAR – McAfeeWebGateway pack  (production integration)
       → Confirmed list types: regex, ip, category, mediatype, string, number
         Confirmed list ID format: com.scur.type.<listtype>.<number>
         Confirmed need to POST /commit after mutations
  9. McAfee MWG 11.0 Product Guide PDF (REST Appendix)
       → Confirmed: /backup, /restore, /commit, /logout, /login endpoints
         File operations: GET /fileserver, GET /troubleshootingfiles
         Engine actions: POST /engine/restart, POST /engine/flush-cache
         Appliance actions: POST /appliance/shutdown, POST /appliance/restart
  10. McAfee Community forums REST scripting thread
       → Confirmed cookie auth, XML Content-Type for writes,
         Accept: application/json OR application/xml for reads

Key enrichments compared to the base settings script:
  - Cookie-based session auth (JSESSIONID) as alternative to Basic Auth
  - Full session lifecycle: login → work → commit → logout
  - Automatic config BACKUP before any write operation (safety net)
  - POST /commit enforcement after every write
  - List-type taxonomy (regex, ip, string, number, category, mediatype)
  - File/log download endpoints discovered from community code
  - Engine control endpoints (restart, flush-cache)
  - Appliance action endpoints (shutdown, restart)
  - Correct XML Content-Type for write operations
  - XSOAR-derived list ID format (com.scur.type.<type>.<n>)

REST base : https://<host>:4712/Konfigurator/REST
Auth      : POST /login  →  JSESSIONID cookie   (preferred)
            HTTP Basic Auth                       (fallback / read-only)

Usage
-----
  pip install requests

  # Pull all settings + list inventory
  python skyhigh_swg_enriched.py --host 192.168.1.10 --user admin --password s3cr3t --pretty

  # Save to file
  python skyhigh_swg_enriched.py --host 192.168.1.10 --user admin --password s3cr3t \\
      --output report.json --pretty

  # Discover which settings sections exist on this appliance
  python skyhigh_swg_enriched.py --host 192.168.1.10 --user admin --password s3cr3t \\
      --discover

  # List known settings sections (no network call)
  python skyhigh_swg_enriched.py --list-sections
"""

import argparse
import json
import logging
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("swg-enriched")

# ─────────────────────────────────────────────────────────────────────────────
# Settings section catalogue
# (original 50 sections + additions discovered from community repos)
# ─────────────────────────────────────────────────────────────────────────────
SETTINGS_SECTIONS: Dict[str, Dict[str, str]] = {
    # ── Proxy & Network ──────────────────────────────────────────────────────
    "ProxySetting":               {"area": "Proxy",           "desc": "Core proxy ports, mode (forward/transparent/ICAP), listeners"},
    "ProxyIcapSetting":           {"area": "Proxy",           "desc": "ICAP server/client config, X-Client-IP, reqmod/respmod"},
    "FtpProxySetting":            {"area": "Proxy",           "desc": "FTP proxy port, passive range, timeouts"},
    "SocksSetting":               {"area": "Proxy",           "desc": "SOCKS4/5 listener configuration"},
    "NetworkSetting":             {"area": "Network",         "desc": "Interface IPs, gateway, MTU"},
    "DnsSetting":                 {"area": "Network",         "desc": "DNS servers, search domains, TTL"},
    "RoutingSetting":             {"area": "Network",         "desc": "Static routes, default gateway"},
    "NtpSetting":                 {"area": "Network",         "desc": "NTP servers, sync interval, timezone"},
    "HostsSetting":               {"area": "Network",         "desc": "Local /etc/hosts entries"},
    # ── SSL / TLS ────────────────────────────────────────────────────────────
    "SslSetting":                 {"area": "SSL/TLS",         "desc": "SSL inspection CA, TLS versions, cipher suites"},
    "SslClientContextSetting":    {"area": "SSL/TLS",         "desc": "Outbound TLS context, trust store, OCSP/CRL"},
    "SslServerContextSetting":    {"area": "SSL/TLS",         "desc": "Inbound TLS context, server cert, ciphers"},
    "SslCaCertificateSetting":    {"area": "SSL/TLS",         "desc": "CA certificate trust store"},
    "SslCertificateSetting":      {"area": "SSL/TLS",         "desc": "Appliance signing certificate"},
    # ── Authentication ───────────────────────────────────────────────────────
    "AuthenticationSetting":      {"area": "Authentication",  "desc": "Auth method (NTLM/Kerberos/LDAP/Basic/None), realm"},
    "NtlmSetting":                {"area": "Authentication",  "desc": "NTLM domain, DC list, machine account"},
    "KerberosSetting":            {"area": "Authentication",  "desc": "Kerberos KDC, realm, keytab"},
    "LdapSetting":                {"area": "Authentication",  "desc": "LDAP/AD server, base DN, bind account, SSL"},
    "RadiusSetting":              {"area": "Authentication",  "desc": "RADIUS server, shared secret, timeout"},
    "SamlSetting":                {"area": "Authentication",  "desc": "SAML 2.0 IdP metadata, SP entity ID"},
    "EDirectory":                 {"area": "Authentication",  "desc": "Novell eDirectory server config"},
    "ProxyAuthSetting":           {"area": "Authentication",  "desc": "Proxy auth challenge, realm string, exempt hosts"},
    # ── Logging ──────────────────────────────────────────────────────────────
    "LogSetting":                 {"area": "Logging",         "desc": "Access log path, rotation, format (W3C/ELFF/custom)"},
    "ErrorLogSetting":            {"area": "Logging",         "desc": "Error/system log, severity, rotation"},
    "AuditLogSetting":            {"area": "Logging",         "desc": "Admin audit log (enabled/path)"},
    "SyslogSetting":              {"area": "Logging",         "desc": "Syslog forwarding: server, port, protocol, facility"},
    "MwgLogSetting":              {"area": "Logging",         "desc": "MWG-specific log handler"},
    "StatisticsSetting":          {"area": "Logging",         "desc": "Statistics collection interval and counters"},
    # ── Anti-Malware / Scanning ──────────────────────────────────────────────
    "AntiMalwareSetting":         {"area": "Anti-Malware",    "desc": "GAM engine: scan mode, max body size, archive depth"},
    "AvSetting":                  {"area": "Anti-Malware",    "desc": "AV engine selection, update schedule, fallback"},
    "TieServerSetting":           {"area": "Anti-Malware",    "desc": "TIE (Threat Intelligence Exchange) server"},
    "AtdSetting":                 {"area": "Anti-Malware",    "desc": "ATD/Sandbox server: host, port, credentials"},
    "GtiSetting":                 {"area": "Anti-Malware",    "desc": "GTI cloud lookup: reputation threshold, categories"},
    "CloudLookupSetting":         {"area": "Anti-Malware",    "desc": "URL/file reputation cloud lookup"},
    # ── URL Filtering ────────────────────────────────────────────────────────
    "UrlFilterSetting":           {"area": "URL Filtering",   "desc": "URL categorisation DB, update schedule"},
    "CategorySetting":            {"area": "URL Filtering",   "desc": "Category definitions and overrides"},
    # ── Content Inspection / DLP ─────────────────────────────────────────────
    "ContentInspectionSetting":   {"area": "Content",         "desc": "DCI engine mode, max scan size, MIME exclusions"},
    "DlpSetting":                 {"area": "DLP",             "desc": "DLP engine, policy server, incident handling"},
    "MediaTypeSetting":           {"area": "Content",         "desc": "MIME/media-type detection rules"},
    # ── HTTP ─────────────────────────────────────────────────────────────────
    "HttpSetting":                {"area": "HTTP",            "desc": "Keep-alive, pipeline, header limits, XFF/Via injection"},
    "HttpTimeoutSetting":         {"area": "HTTP",            "desc": "Connection/read/write timeouts"},
    "HttpCacheSetting":           {"area": "HTTP",            "desc": "Object caching: size, TTL, bypass rules"},
    "CompressionSetting":         {"area": "HTTP",            "desc": "Gzip/deflate decompression before scanning"},
    "CacheSetting":               {"area": "Caching",         "desc": "Global cache on/off, disk path and size"},
    # ── Users & Roles ────────────────────────────────────────────────────────
    "UserSetting":                {"area": "Users",           "desc": "Local appliance user accounts and roles"},
    "RoleSetting":                {"area": "Users",           "desc": "Administrator role definitions and permissions"},
    # ── Notifications ────────────────────────────────────────────────────────
    "NotificationSetting":        {"area": "Notifications",   "desc": "Block/warn page templates, logos, redirect URLs"},
    "AlertSetting":               {"area": "Notifications",   "desc": "SNMP/email alert thresholds and recipients"},
    "SmtpSetting":                {"area": "Notifications",   "desc": "SMTP relay: server, port, sender, TLS"},
    "SnmpSetting":                {"area": "Notifications",   "desc": "SNMP v1/v2c/v3 agent and trap-receiver config"},
    # ── Central Management / Cluster ────────────────────────────────────────
    "CentralManagementSetting":   {"area": "Central Mgmt",   "desc": "CM mode (standalone/CM/managed), CM address, sync"},
    "ClusterSetting":             {"area": "Central Mgmt",   "desc": "Cluster membership, LB group, heartbeat interval"},
    "ConfigurationBackupSetting": {"area": "Central Mgmt",   "desc": "Automated backup schedule, remote path (SCP/FTP)"},
    # ── Updates ──────────────────────────────────────────────────────────────
    "UpdateSetting":              {"area": "Updates",         "desc": "DAT/engine update schedule, update server URLs"},
    "EngineUpdateSetting":        {"area": "Updates",         "desc": "Anti-malware engine update policy and rollback"},
    # ── High Availability ────────────────────────────────────────────────────
    "HaSetting":                  {"area": "HA",              "desc": "HA mode, virtual IP, preempt, heartbeat interface"},
    # ── System / Monitoring ──────────────────────────────────────────────────
    "HealthSetting":              {"area": "System",          "desc": "Health thresholds: CPU, memory, disk, connections"},
    "SystemSetting":              {"area": "System",          "desc": "Hostname, locale, admin session timeout"},
    "DiagnosticSetting":          {"area": "System",          "desc": "Debug log verbosity, packet-capture settings"},
    # ── PAC / Bypass ─────────────────────────────────────────────────────────
    "PacSetting":                 {"area": "PAC",             "desc": "PAC file hosting: path and content"},
    "BypassSetting":              {"area": "Bypass",          "desc": "Global bypass list: source IPs/destinations"},
    # ── Reporting ────────────────────────────────────────────────────────────
    "ReportingSetting":           {"area": "Reporting",       "desc": "Reporting: data retention, schedule, export format"},
    "DashboardSetting":           {"area": "Reporting",       "desc": "Dashboard widget configuration"},
    # ── Licensing ────────────────────────────────────────────────────────────
    "LicenseSetting":             {"area": "Licensing",       "desc": "License key, subscription, feature entitlements"},
    # ── Privacy / Telemetry ──────────────────────────────────────────────────
    "FeedbackSetting":            {"area": "Privacy",         "desc": "Telemetry/feedback opt-in"},
    # ── ICAP-specific (discovered via SkyhighSecurity/ScannerAPI*) ───────────
    "IcapSetting":                {"area": "ICAP",            "desc": "ICAP listener: port 1344, max connections, X-headers"},
    "IcapClientSetting":          {"area": "ICAP",            "desc": "Outbound ICAP client: remote server, timeout"},
    # ── Engine-level settings (discovered via MWG Product Guide REST PDF) ────
    "EngineSetting":              {"area": "Engine",          "desc": "Gateway engine: worker threads, queue depth"},
    "CoreSetting":                {"area": "Engine",          "desc": "Core process settings and resource limits"},
    # ── Kerberos Constrained Delegation ──────────────────────────────────────
    "KcdSetting":                 {"area": "Authentication",  "desc": "Kerberos Constrained Delegation for SSO"},
    # ── Client Proxy (Skyhigh Client Proxy integration) ──────────────────────
    "ClientProxySetting":         {"area": "Client Proxy",   "desc": "SCP (Skyhigh Client Proxy) integration config"},
}

# ─────────────────────────────────────────────────────────────────────────────
# Enriched: List type taxonomy
# Source: Cortex XSOAR McAfeeWebGateway pack + mohlcyber/McAfee-Web-Gateway-List-Update
# List IDs follow the pattern: com.scur.type.<listtype>.<sequential_number>
# ─────────────────────────────────────────────────────────────────────────────
LIST_TYPES = {
    "regex":     "URL/pattern lists – most common block/allow list type",
    "ip":        "IP address lists (CIDR notation supported)",
    "string":    "Arbitrary string lists (hostnames, user-agents, etc.)",
    "number":    "Numeric value lists (port numbers, response codes, etc.)",
    "category":  "Web category lists (numeric category IDs)",
    "mediatype": "MIME/media-type lists",
    "stat":      "Statistics counters",
    "composite": "Composite / combined type lists",
}


# ─────────────────────────────────────────────────────────────────────────────
# REST Client
# ─────────────────────────────────────────────────────────────────────────────
class SWGClient:
    """
    Enriched REST client for Skyhigh / McAfee SWG on-prem.

    Auth flow (confirmed by mohlcyber, firewallops, Ipv6Python, IntelSecurityGroup):
      POST /login  →  200 + Set-Cookie: JSESSIONID=<token>
      All subsequent requests must carry Cookie: JSESSIONID=<token>
      POST /logout  →  session invalidated

    Write flow (confirmed by mohlcyber + MWG Product Guide):
      POST /backup            ← optional but recommended safety backup
      <write operation>       ← PUT/POST/DELETE on list/settings/etc.
      POST /commit            ← MANDATORY – changes are not persisted without this
    """

    DEFAULT_PORT = 4712
    BASE = "/Konfigurator/REST"

    def __init__(
        self,
        host: str,
        username: str,
        password: str,
        port: int = DEFAULT_PORT,
        verify_ssl: bool = False,
        timeout: int = 30,
        max_workers: int = 8,
    ):
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.verify_ssl = verify_ssl
        self.timeout = timeout
        self.max_workers = max_workers
        self.base_url = f"https://{host}:{port}{self.BASE}"

        # Shared session – carries cookie + headers
        self._session = requests.Session()
        self._session.verify = verify_ssl
        self._session.headers.update({
            "Accept": "application/json",
        })
        self._authenticated_with_cookie = False

    # ── Session lifecycle ────────────────────────────────────────────────────

    def login(self) -> bool:
        """
        POST /login – obtain JSESSIONID cookie.
        Source: mohlcyber/McAfee-Web-Gateway-List-Update, firewallops/SwgAssistant,
                IntelSecurityGroup/webgateway
        """
        url = f"{self.base_url}/login"
        try:
            resp = self._session.post(
                url,
                params={"username": self.username, "password": self.password},
                headers={"Content-Type": "application/xml"},
                timeout=self.timeout,
            )
            resp.raise_for_status()
            if "JSESSIONID" in self._session.cookies:
                self._authenticated_with_cookie = True
                log.info("Session established  (JSESSIONID cookie)")
                return True
            # Fallback: some versions return the token in the body
            log.warning("Login OK but no JSESSIONID cookie – falling back to Basic Auth")
            self._session.auth = (self.username, self.password)
            return True
        except requests.HTTPError as exc:
            log.warning("Cookie login failed (HTTP %s) – falling back to Basic Auth",
                        exc.response.status_code if exc.response else "?")
            self._session.auth = (self.username, self.password)
            return True  # Basic Auth still available
        except Exception as exc:
            log.error("Login error: %s  – falling back to Basic Auth", exc)
            self._session.auth = (self.username, self.password)
            return True

    def logout(self) -> None:
        """POST /logout – invalidate JSESSIONID. Source: mohlcyber."""
        if not self._authenticated_with_cookie:
            return
        try:
            self._session.post(
                f"{self.base_url}/logout",
                headers={"Content-Type": "application/xml"},
                timeout=self.timeout,
            )
            log.info("Session terminated (logout)")
        except Exception as exc:
            log.debug("Logout error (non-fatal): %s", exc)

    # ── Low-level helpers ────────────────────────────────────────────────────

    def _url(self, path: str) -> str:
        return f"{self.base_url}/{path.lstrip('/')}"

    def _get(self, path: str, params: Optional[Dict] = None, accept: str = "application/json") -> Any:
        headers = {"Accept": accept}
        resp = self._session.get(self._url(path), params=params,
                                 headers=headers, timeout=self.timeout)
        resp.raise_for_status()
        if not resp.content.strip():
            return {}
        try:
            return resp.json()
        except ValueError:
            return {"_raw": resp.text}

    def _post(self, path: str, data: Optional[str] = None,
              content_type: str = "application/xml") -> Any:
        headers = {"Content-Type": content_type}
        resp = self._session.post(self._url(path), data=data,
                                  headers=headers, timeout=self.timeout)
        resp.raise_for_status()
        if not resp.content.strip():
            return {}
        try:
            return resp.json()
        except ValueError:
            return {"_raw": resp.text}

    # ── Connectivity ─────────────────────────────────────────────────────────

    def ping(self) -> bool:
        try:
            self._get("version")
            return True
        except Exception as exc:
            log.error("Cannot reach %s:%s  –  %s", self.host, self.port, exc)
            return False

    def get_version(self) -> Dict:
        return self._get("version")

    # ── Backup (safety net before writes) ────────────────────────────────────

    def backup(self, encrypted: bool = False, password: Optional[str] = None) -> bytes:
        """
        POST /backup – create a configuration backup archive.
        Source: mohlcyber/McAfee-Web-Gateway-List-Update, MWG 11.0 Product Guide

        Returns raw bytes of the backup archive (ZIP).
        Always call this before any write operation!
        """
        params: Dict[str, Any] = {}
        if encrypted and password:
            params["encrypted"] = "true"
            params["password"] = password
        resp = self._session.post(
            self._url("backup"),
            params=params,
            headers={"Content-Type": "application/xml"},
            timeout=max(self.timeout, 120),
        )
        resp.raise_for_status()
        log.info("Config backup created  (%d bytes)", len(resp.content))
        return resp.content

    # ── Commit (mandatory after writes) ──────────────────────────────────────

    def commit(self) -> None:
        """
        POST /commit – persist staged changes to disk.
        Source: mohlcyber, firewallops, MWG Product Guide.
        WITHOUT this call, all write operations are silently discarded!
        """
        self._post("commit")
        log.info("Changes committed")

    # ── Settings (core focus of this script) ─────────────────────────────────

    def get_settings_root(self) -> Any:
        """GET /settings – top-level settings index."""
        return self._get("settings")

    def get_setting(self, section: str) -> Tuple[str, Any]:
        """Fetch one named settings section. Returns (section_name, data_or_error)."""
        try:
            data = self._get(f"settings/{section}")
            log.info("  ✓  %-45s", section)
            return section, data
        except requests.HTTPError as exc:
            code = exc.response.status_code if exc.response is not None else "?"
            if code == 404:
                log.debug("  –  %-45s  (404 – not present on this appliance)", section)
            else:
                log.warning("  ✗  %-45s  HTTP %s", section, code)
            return section, {"_error": str(exc), "_http_status": code}
        except Exception as exc:
            log.warning("  ✗  %-45s  %s", section, exc)
            return section, {"_error": str(exc)}

    def get_all_settings(self, sections: Optional[List[str]] = None) -> Dict[str, Any]:
        """Fetch all known settings sections in parallel."""
        names = sections or list(SETTINGS_SECTIONS.keys())
        results: Dict[str, Any] = {}
        log.info("Fetching %d settings sections in parallel (workers=%d) …",
                 len(names), self.max_workers)
        with ThreadPoolExecutor(max_workers=self.max_workers) as pool:
            futures = {pool.submit(self.get_setting, n): n for n in names}
            for f in as_completed(futures):
                name, data = f.result()
                results[name] = data
        return results

    def discover_sections(self) -> List[str]:
        """Return sorted list of sections that respond HTTP 200."""
        log.info("Discovering available sections …")
        found: List[str] = []
        with ThreadPoolExecutor(max_workers=self.max_workers) as pool:
            futures = {pool.submit(self.get_setting, n): n for n in SETTINGS_SECTIONS}
            for f in as_completed(futures):
                name, data = f.result()
                if "_http_status" not in data:
                    found.append(name)
        return sorted(found)

    # ── Lists (enriched from mohlcyber + XSOAR pack) ─────────────────────────

    def get_lists(self, name_filter: Optional[str] = None,
                  type_filter: Optional[str] = None) -> Any:
        """
        GET /list – all configured lists.
        Supports name/type filters (confirmed in XSOAR McAfeeWebGateway pack).
        Source: mohlcyber, Cortex XSOAR integration docs.
        """
        params: Dict[str, str] = {}
        if name_filter:
            params["name"] = name_filter
        if type_filter:
            params["type"] = type_filter
        return self._get("list", params=params, accept="application/json")

    def get_list(self, list_id: str) -> Any:
        """
        GET /list/{id} – retrieve a specific list and all its entries.
        List IDs follow the pattern: com.scur.type.<type>.<n>
        Source: Cortex XSOAR pack, mohlcyber.
        """
        return self._get(f"list/{list_id}", accept="application/json")

    def get_list_entry(self, list_id: str, position: int) -> Any:
        """GET /list/{id}/entry/{pos} – single list entry. Source: XSOAR pack."""
        return self._get(f"list/{list_id}/entry/{position}", accept="application/json")

    # ── File / Log operations (discovered from MWG Product Guide PDF) ────────

    def get_log_files(self) -> Any:
        """
        GET /fileserver – list available log files on the appliance.
        Source: MWG 11.0 REST Product Guide appendix.
        """
        try:
            return self._get("fileserver")
        except requests.HTTPError as exc:
            return {"_error": str(exc),
                    "_http_status": exc.response.status_code if exc.response else "?"}

    def get_troubleshooting_files(self) -> Any:
        """
        GET /troubleshootingfiles – list uploaded troubleshooting files.
        Source: MWG 11.0 REST Product Guide appendix.
        """
        try:
            return self._get("troubleshootingfiles")
        except requests.HTTPError as exc:
            return {"_error": str(exc),
                    "_http_status": exc.response.status_code if exc.response else "?"}

    # ── Engine actions (discovered from MWG Product Guide + community) ────────

    def flush_cache(self) -> Any:
        """
        POST /engine/flush-cache – flush the HTTP proxy cache.
        Source: MWG Product Guide REST appendix.
        """
        try:
            return self._post("engine/flush-cache")
        except requests.HTTPError as exc:
            return {"_error": str(exc)}

    # ── Appliances / Nodes ───────────────────────────────────────────────────

    def get_appliances(self) -> Any:
        """GET /appliances – all appliances/nodes in the cluster."""
        try:
            data = self._get("appliances")
            if isinstance(data, list):
                return data
            for key in ("appliances", "nodes", "results"):
                if key in data:
                    return data[key]
            return [data] if data else []
        except Exception as exc:
            return {"_error": str(exc)}

    # ── Full report builder ──────────────────────────────────────────────────

    def build_report(
        self,
        sections: Optional[List[str]] = None,
        include_lists: bool = True,
        include_file_inventory: bool = True,
        include_meta: bool = True,
    ) -> Dict[str, Any]:
        """
        Collect all settings, list inventory, file inventory and appliance
        details into one consolidated JSON-serialisable dict.
        """
        report: Dict[str, Any] = {
            "meta": {
                "collected_at": datetime.now(timezone.utc).isoformat(),
                "host": self.host,
                "port": self.port,
                "auth_method": "JSESSIONID" if self._authenticated_with_cookie else "BasicAuth",
                "github_enrichments": [
                    "SkyhighSecurity/ScannerAPI-Python",
                    "SkyhighSecurity/ScannerAPI",
                    "SkyhighSecurity/skyhigh-trellix-dod-integrator",
                    "firewallops/SwgAssistant",
                    "mohlcyber/McAfee-Web-Gateway-List-Update",
                    "Ipv6Python/mcafee-mwgapi",
                    "IntelSecurityGroup/webgateway",
                    "PaloAlto-Cortex-XSOAR/McAfeeWebGateway-pack",
                    "MWG-11.0-Product-Guide-REST-Appendix",
                ],
            },
        }

        # Version
        log.info("Fetching version …")
        try:
            report["version"] = self.get_version()
        except Exception as exc:
            report["version"] = {"_error": str(exc)}

        # Appliances
        log.info("Fetching appliances …")
        report["appliances"] = self.get_appliances()

        # Settings root
        log.info("Fetching settings root …")
        try:
            report["settings_root"] = self.get_settings_root()
        except Exception as exc:
            report["settings_root"] = {"_error": str(exc)}

        # All settings sections
        report["settings"] = self.get_all_settings(sections)

        # List inventory
        if include_lists:
            log.info("Fetching list inventory …")
            try:
                report["lists"] = self.get_lists()
            except Exception as exc:
                report["lists"] = {"_error": str(exc)}

        # File inventory
        if include_file_inventory:
            log.info("Fetching file/log inventory …")
            report["log_files"] = self.get_log_files()
            report["troubleshooting_files"] = self.get_troubleshooting_files()

        # Catalogue metadata
        if include_meta:
            settings = report.get("settings", {})
            report["section_catalogue"] = {
                name: {
                    "area": info["area"],
                    "description": info["desc"],
                    "available": "_error" not in settings.get(name, {"_error": "not queried"}),
                }
                for name, info in SETTINGS_SECTIONS.items()
            }
            report["list_type_taxonomy"] = LIST_TYPES

        return report


# ─────────────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────────────
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Enriched Skyhigh SWG settings collector (GitHub-sourced enrichments)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    conn = p.add_argument_group("Connection")
    conn.add_argument("--host")
    conn.add_argument("--port", type=int, default=SWGClient.DEFAULT_PORT)
    conn.add_argument("--user")
    conn.add_argument("--password")
    conn.add_argument("--verify-ssl", action="store_true")
    conn.add_argument("--timeout", type=int, default=30)
    conn.add_argument("--workers", type=int, default=8)

    mode = p.add_argument_group("Mode")
    mode.add_argument("--section", metavar="NAME",
                      help="Pull only one settings section")
    mode.add_argument("--list-sections", action="store_true",
                      help="Print catalogue of all known sections (no network)")
    mode.add_argument("--discover", action="store_true",
                      help="Probe all sections, report which respond HTTP 200")
    mode.add_argument("--no-lists", action="store_true",
                      help="Skip list inventory")
    mode.add_argument("--no-files", action="store_true",
                      help="Skip log/troubleshooting file inventory")
    mode.add_argument("--no-meta", action="store_true",
                      help="Omit catalogue metadata from output")

    out = p.add_argument_group("Output")
    out.add_argument("--output", "-o", metavar="FILE")
    out.add_argument("--pretty", action="store_true")
    out.add_argument("--debug", action="store_true")
    return p


def _need_conn(args: argparse.Namespace) -> None:
    missing = [f for f in ("host", "user", "password") if not getattr(args, f)]
    if missing:
        log.error("Missing: %s", ", ".join(f"--{m}" for m in missing))
        sys.exit(1)


def _write(data: Any, args: argparse.Namespace) -> None:
    indent = 2 if args.pretty else None
    text = json.dumps(data, indent=indent, default=str, ensure_ascii=False)
    if args.output:
        with open(args.output, "w", encoding="utf-8") as fh:
            fh.write(text + "\n")
        log.info("Report saved → %s", args.output)
    else:
        print(text)


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    if args.debug:
        logging.getLogger().setLevel(logging.DEBUG)

    # Offline: list known sections
    if args.list_sections:
        print(f"\n{'Section Name':<48} {'Area':<20} Description")
        print("─" * 120)
        prev_area = ""
        for name, info in sorted(SETTINGS_SECTIONS.items(), key=lambda x: (x[1]["area"], x[0])):
            sep = "\n" if info["area"] != prev_area else ""
            print(f"{sep}{name:<48} {info['area']:<20} {info['desc'][:55]}")
            prev_area = info["area"]
        print(f"\nTotal: {len(SETTINGS_SECTIONS)} sections across "
              f"{len({i['area'] for i in SETTINGS_SECTIONS.values()})} functional areas")
        print(f"\nList types: {', '.join(LIST_TYPES.keys())}")
        return 0

    _need_conn(args)
    client = SWGClient(
        host=args.host, username=args.user, password=args.password,
        port=args.port, verify_ssl=args.verify_ssl,
        timeout=args.timeout, max_workers=args.workers,
    )
    client.login()

    if not client.ping():
        client.logout()
        return 1

    try:
        if args.discover:
            available = client.discover_sections()
            print(f"\nAvailable sections on {args.host} ({len(available)} of "
                  f"{len(SETTINGS_SECTIONS)} known):\n")
            for name in available:
                info = SETTINGS_SECTIONS.get(name, {})
                print(f"  {name:<48} ({info.get('area', '')})")
            return 0

        if args.section:
            _, data = client.get_setting(args.section)
            _write({
                "meta": {"host": args.host, "section": args.section,
                         "collected_at": datetime.now(timezone.utc).isoformat()},
                args.section: data,
            }, args)
            return 0

        # Full report
        report = client.build_report(
            include_lists=not args.no_lists,
            include_file_inventory=not args.no_files,
            include_meta=not args.no_meta,
        )
        _write(report, args)

        settings = report.get("settings", {})
        ok = sum(1 for v in settings.values() if "_error" not in v)
        fail = len(settings) - ok
        log.info("Done. Settings: %d OK / %d unavailable. "
                 "Total sections queried: %d", ok, fail, len(settings))

    finally:
        client.logout()

    return 0


if __name__ == "__main__":
    sys.exit(main())
