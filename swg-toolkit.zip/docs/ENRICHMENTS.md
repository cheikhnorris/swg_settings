# GitHub Research Enrichments

This document records all public GitHub repositories and community sources that were
analysed to enrich this toolkit beyond what the official Skyhigh documentation exposes.

---

## Sources

### 1. SkyhighSecurity/ScannerAPI-Python (Official)
**URL:** https://github.com/SkyhighSecurity/ScannerAPI-Python  
**Language:** Python · MIT License  
**What it revealed:**
- ICAP-to-REST bridge pattern: wraps the ICAP protocol (RFC 3507) in a familiar REST API
- Confirmed `IcapSetting` and `IcapClientSetting` as valid settings section names
- Revealed environment variables `ICAPSERVER`, `ICAPPORT`, `ICAPCLIENT` used in containerised deployments
- Shows `/dlpscan` endpoint for DLP scanning via McAfee MVC API

### 2. SkyhighSecurity/ScannerAPI (Official, C#)
**URL:** https://github.com/SkyhighSecurity/ScannerAPI  
**Language:** C# · AGPL-3.0  
**What it revealed:**
- Same ICAP patterns as Python version, confirms cross-language consistency
- Can run as Azure Function or Docker container
- Confirms `/reqmod` and `/respmod` ICAP modes

### 3. SkyhighSecurity/skyhigh-trellix-dod-integrator (Official)
**URL:** https://github.com/SkyhighSecurity/skyhigh-trellix-dod-integrator  
**Language:** Python/Flask  
**What it revealed:**
- Simulates the ATD/TIS (Advanced Threat Detection / Trellix Intelligence Sandbox) API
- Confirmed `AtdSetting` and `TieServerSetting` as valid REST settings sections
- Shows the full ATD integration pattern used in production

### 4. firewallops/SwgAssistant (Community)
**URL:** https://github.com/firewallops/SwgAssistant  
**Language:** Python · MIT License  
**What it revealed:**
- JSESSIONID cookie as the correct and preferred session mechanism
- Session reuse pattern — create once, reuse across all requests in the run
- Confirmed the cookie is returned from `POST /login` as `Set-Cookie: JSESSIONID=<token>`

### 5. mohlcyber/McAfee-Web-Gateway-List-Update (Community) ⭐ Most Useful
**URL:** https://github.com/mohlcyber/McAfee-Web-Gateway-List-Update  
**Language:** Python  
**What it revealed:**
- Complete write flow, confirmed in actual working code:
  ```
  POST /Konfigurator/REST/login      → JSESSIONID cookie
  POST /Konfigurator/REST/backup     → safety backup before writes
  GET  /Konfigurator/REST/list       → list all configured lists
  POST /Konfigurator/REST/list/{id}/entry/{pos}/insert  → add entry
  PUT  /Konfigurator/REST/list/{id}/entry/{pos}         → update entry
  DELETE /Konfigurator/REST/list/{id}/entry/{pos}       → remove entry
  POST /Konfigurator/REST/commit     → MANDATORY persist to disk
  POST /Konfigurator/REST/logout     → invalidate session
  ```
- `Content-Type: application/xml` required for write operations
- List ID format: `com.scur.type.<type>.<number>` (e.g. `com.scur.type.ip.316`)
- Integration with McAfee ESM for right-click block actions

### 6. Ipv6Python/mcafee-mwgapi (Community)
**URL:** https://github.com/Ipv6Python/mcafee-mwgapi  
**Language:** Python · GPL-2.0  
**What it revealed:**
- Pip-installable package structure for MWG API — confirms these patterns are worth packaging
- `authenticate` → `appliances` → `listdata` module separation pattern
- Based on KateLibC/McAfeeWebGateway (GPL-2.0, 2017) — confirms long community history

### 7. IntelSecurityGroup/webgateway (Community)
**URL:** https://github.com/IntelSecurityGroup/webgateway  
**Language:** Go  
**What it revealed:**
- Cross-language confirmation that cookie auth + SSL skip is the standard approach
- `ignoressl` flag pattern (maps to `--verify-ssl` in our CLI)
- Confirms the same host/user/pass/port parameter set across all implementations

### 8. Palo Alto Cortex XSOAR — McAfeeWebGateway Pack (Production Integration)
**URL:** https://xsoar.pan.dev/docs/reference/integrations/skyhigh-secure-web-gateway-on-prem  
**Tested with:** SWG 11.2.9  
**What it revealed:**
- Complete list type taxonomy: `regex`, `ip`, `string`, `number`, `category`, `mediatype`
- List ID format confirmed: `com.scur.type.<type>.<n>`
- Commands mapped to REST endpoints:
  - `swg-get-available-lists` → `GET /list` (with name/type filter params)
  - `swg-get-list` → `GET /list/{id}`
  - `swg-get-list-entry` → `GET /list/{id}/entry/{pos}`
  - `swg-insert-entry` → `POST /list/{id}/entry/{pos}/insert`
  - `swg-delete-entry` → `DELETE /list/{id}/entry/{pos}`
  - `swg-update-list` → `PUT /list/{id}` (full XML overwrite)
- POST /commit is mandatory and explicitly called after every mutation
- Context output schema for SOAR automation (SWG.List.ID, SWG.List.Title, SWG.List.Type)

### 9. McAfee/Skyhigh MWG 11.0 Product Guide — REST Interface Appendix (PDF)
**URL:** https://success.skyhighsecurity.com/@api/deki/files/39920/MWG_11.0_Product_Guide_App_F_REST_Interface.pdf  
**What it revealed:**
- Official confirmation of `/backup` and `/restore` with `encrypted` and `password` params
- File operations:
  - `GET /fileserver` — list available log files
  - `GET /troubleshootingfiles` — list uploaded troubleshooting files
- Engine actions:
  - `POST /engine/restart`
  - `POST /engine/flush-cache`
- Appliance actions:
  - `POST /appliance/shutdown`
  - `POST /appliance/restart`
- Settings write flow: `PUT /settings/<section>` → `POST /commit`
- Filter/engine settings can be added by name with XML body

### 10. McAfee Community Forum — REST Scripting Thread
**URL:** https://community.mcafee.com/t5/Web-Gateway/Examples-of-REST-scripting/td-p/336462  
**What it revealed:**
- Earliest confirmed REST examples (MWG 7.x era, still valid)
- `Authorization: Basic <base64>` header for initial login, then cookie for subsequent calls
- `Content-Type: application/xml` confirmed for writes
- `curl -c cookies.txt` pattern = JSESSIONID cookie storage
- List entry XML format: `<listEntryRequest><entry>…</entry></listEntryRequest>`

---

## Summary of Enrichments Applied

| Enrichment | Source |
|---|---|
| JSESSIONID cookie auth (preferred over Basic) | firewallops, mohlcyber, IntelSecurityGroup |
| Proper `login()` / `logout()` session lifecycle | mohlcyber, MWG Product Guide |
| `backup()` safety method before writes | mohlcyber, MWG Product Guide |
| `commit()` method — mandatory after writes | mohlcyber, XSOAR pack, MWG Product Guide |
| List CRUD operations (`get_lists`, `get_list`, `get_list_entry`) | mohlcyber, XSOAR pack |
| List type taxonomy (regex/ip/string/number/category/mediatype) | XSOAR pack |
| List ID format `com.scur.type.<type>.<n>` | mohlcyber, XSOAR pack |
| `IcapSetting`, `IcapClientSetting` section names | SkyhighSecurity/ScannerAPI-Python |
| `AtdSetting`, `TieServerSetting` confirmed | SkyhighSecurity/skyhigh-trellix-dod-integrator |
| `EngineSetting`, `CoreSetting` section names | MWG Product Guide |
| `KcdSetting` (Kerberos Constrained Delegation) | MWG Product Guide |
| `ClientProxySetting` (Skyhigh Client Proxy) | SkyhighSecurity org repos |
| `GET /fileserver` — log file inventory | MWG Product Guide |
| `GET /troubleshootingfiles` — troubleshooting files | MWG Product Guide |
| `POST /engine/flush-cache` — cache flush action | MWG Product Guide |
| XML `Content-Type` for write operations | mohlcyber, MWG community forum |
| `--verify-ssl` off by default + `ignoressl` pattern | IntelSecurityGroup/webgateway |
