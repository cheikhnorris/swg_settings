# Settings Sections Catalogue

All known `GET /Konfigurator/REST/settings/<SectionName>` endpoints, grouped by functional area.

> Run `python skyhigh_swg_settings.py --list-sections` to print this list with availability status.

---

## Proxy & Network

| Section | Description |
|---|---|
| `ProxySetting` | Core proxy ports, mode (forward/transparent/ICAP), listener configuration |
| `ProxyIcapSetting` | ICAP server/client config, X-Client-IP header, reqmod/respmod |
| `FtpProxySetting` | FTP proxy port, passive mode ranges, timeouts |
| `SocksSetting` | SOCKS4/5 listener configuration |
| `NetworkSetting` | Interface IP addresses, gateway, MTU |
| `DnsSetting` | DNS servers (primary/secondary), search domains, TTL |
| `RoutingSetting` | Static routes, routing table, default gateway |
| `NtpSetting` | NTP server list, sync interval, time-zone |
| `HostsSetting` | Local /etc/hosts entries managed via the UI |

## SSL / TLS

| Section | Description |
|---|---|
| `SslSetting` | SSL inspection: CA certificate, TLS versions, cipher suites |
| `SslClientContextSetting` | Outbound (client→server) TLS context, trust store, OCSP/CRL |
| `SslServerContextSetting` | Inbound (browser→proxy) TLS context, server cert, ciphers |
| `SslCaCertificateSetting` | CA certificate trust store for SSL inspection |
| `SslCertificateSetting` | Appliance signing certificate used to re-generate certs |

## Authentication

| Section | Description |
|---|---|
| `AuthenticationSetting` | Global method (NTLM/Kerberos/LDAP/Basic/None), auth realm |
| `NtlmSetting` | NTLM domain, DC list, machine account, NTLM version |
| `KerberosSetting` | Kerberos KDC list, realm, keytab configuration |
| `LdapSetting` | LDAP/AD server, base DN, bind account, user/group attrs, SSL |
| `RadiusSetting` | RADIUS server, shared secret, timeout, retry count |
| `SamlSetting` | SAML 2.0 IdP metadata, SP entity ID, ACS URL |
| `EDirectory` | Novell eDirectory server config |
| `ProxyAuthSetting` | Proxy auth challenge: realm string, exempt hosts/networks |
| `KcdSetting` | Kerberos Constrained Delegation for SSO |

## Logging

| Section | Description |
|---|---|
| `LogSetting` | Access log: path, rotation, format (W3C/ELFF/custom), fields |
| `ErrorLogSetting` | Error/system log: path, severity level, rotation |
| `AuditLogSetting` | Admin audit log for UI/API actions |
| `SyslogSetting` | Syslog forwarding: server, port, protocol (UDP/TCP/TLS), facility |
| `MwgLogSetting` | MWG-specific log handler configuration |
| `StatisticsSetting` | Statistics collection interval and counters |

## Anti-Malware / Scanning

| Section | Description |
|---|---|
| `AntiMalwareSetting` | GAM engine: scan mode, max body size, archive depth/timeout |
| `AvSetting` | AV engine selection, update schedule, fallback policy |
| `TieServerSetting` | McAfee TIE (Threat Intelligence Exchange) server connection |
| `AtdSetting` | ATD/Sandbox server: host, port, credentials, timeout |
| `GtiSetting` | GTI cloud lookup: reputation threshold, categories |
| `CloudLookupSetting` | URL/file reputation cloud lookup configuration |

## URL Filtering

| Section | Description |
|---|---|
| `UrlFilterSetting` | URL categorisation DB path, update schedule, uncategorised handling |
| `CategorySetting` | Category definitions and overrides |

## Content Inspection / DLP

| Section | Description |
|---|---|
| `ContentInspectionSetting` | DCI engine mode, max scan size, MIME type exclusions |
| `DlpSetting` | DLP engine, policy server, incident handling |
| `MediaTypeSetting` | MIME/media-type detection rules and overrides |

## HTTP

| Section | Description |
|---|---|
| `HttpSetting` | Keep-alive, pipeline, header size limits, X-Forwarded-For, Via header |
| `HttpTimeoutSetting` | Connection/read/write timeouts for client and server sides |
| `HttpCacheSetting` | Object caching: size, TTL policies, bypass rules |
| `CompressionSetting` | Gzip/deflate decompression of responses before scanning |
| `CacheSetting` | Global cache on/off, disk cache path and size |

## Users & Roles

| Section | Description |
|---|---|
| `UserSetting` | Local appliance user accounts and roles |
| `RoleSetting` | Administrator role definitions and permission mappings |

## Notifications & Alerts

| Section | Description |
|---|---|
| `NotificationSetting` | Block/warn page templates, logos, redirect URLs |
| `AlertSetting` | SNMP/email alert thresholds and recipients |
| `SmtpSetting` | SMTP relay: server, port, sender address, TLS |
| `SnmpSetting` | SNMP v1/v2c/v3 agent and trap-receiver configuration |

## Central Management / Cluster

| Section | Description |
|---|---|
| `CentralManagementSetting` | CM mode (standalone/CM node/managed), CM address, sync schedule |
| `ClusterSetting` | Cluster membership, load-balancing group, heartbeat interval |
| `ConfigurationBackupSetting` | Automated backup: schedule, remote path (SCP/FTP) |

## Updates

| Section | Description |
|---|---|
| `UpdateSetting` | DAT/engine update schedule, update server URLs, update proxy |
| `EngineUpdateSetting` | Anti-malware engine update policy (auto-update, rollback) |

## High Availability

| Section | Description |
|---|---|
| `HaSetting` | HA mode, virtual IP, preempt, heartbeat interface |

## System / Monitoring

| Section | Description |
|---|---|
| `HealthSetting` | Health-check thresholds: CPU, memory, disk, connections |
| `SystemSetting` | Hostname, locale, admin session timeout |
| `DiagnosticSetting` | Debug log verbosity and packet-capture settings |

## PAC / Bypass

| Section | Description |
|---|---|
| `PacSetting` | PAC file hosting: path and content |
| `BypassSetting` | Global bypass list: source IPs/destinations that skip inspection |

## Reporting

| Section | Description |
|---|---|
| `ReportingSetting` | Built-in reporting: data retention, schedule, export format |
| `DashboardSetting` | Dashboard widget configuration |

## ICAP (discovered via SkyhighSecurity/ScannerAPI-Python)

| Section | Description |
|---|---|
| `IcapSetting` | ICAP listener: port 1344, max connections, X-headers |
| `IcapClientSetting` | Outbound ICAP client: remote server address, timeout |

## Engine (discovered via MWG Product Guide REST appendix)

| Section | Description |
|---|---|
| `EngineSetting` | Gateway engine: worker threads, queue depth, resource limits |
| `CoreSetting` | Core process settings and resource limits |

## Client Proxy Integration

| Section | Description |
|---|---|
| `ClientProxySetting` | Skyhigh Client Proxy (SCP) integration configuration |

## Licensing & Privacy

| Section | Description |
|---|---|
| `LicenseSetting` | License key, subscription status, feature entitlements |
| `FeedbackSetting` | Telemetry/feedback reporting opt-in |
